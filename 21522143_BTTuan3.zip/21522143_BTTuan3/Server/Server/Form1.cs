﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            Connect();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        IPEndPoint IP;
        Socket server;
        List<Socket> ClientList;


        void Connect()
        {
            ClientList = new List<Socket>();
            IP = new IPEndPoint(IPAddress.Any, 9999);
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            
            

            server.Bind(IP);

            Thread Listen = new Thread(() =>
            {
                try
                {
                    while (true)
                    {
                        server.Listen(100);
                        Socket client = server.Accept();
                        ClientList.Add(client);

                        Thread receive = new Thread(Receive);
                        receive.IsBackground = true;
                        receive.Start(client);
                    }
                }catch {
                    IP = new IPEndPoint(IPAddress.Any, 9999);
                    server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
                }

                
                

            } );
            Listen.IsBackground = true;
            Listen.Start();

        }

        void close()
        {
            server.Close();
        }
        void Send(Socket client)
        {
            
            if (textBox_in.Text != string.Empty)
                client.Send(Serialize(textBox_in.Text));

        }

        void Receive(object obj )
        {

            Socket client = obj as Socket;
            try
            {   while(true) {
                    byte[] data = new byte[1024 * 5000];
                    client.Receive(data);

                    string data_tosend = (string)Deserialize(data);
                    Addmessage(data_tosend);
                }
                
            }
            catch
            {
                ClientList.Remove(client);
                client.Close();
            }
        }

        void Addmessage(string s)
        {
            listView1.Items.Add(new ListViewItem() { Text = s });
            textBox_in.Clear();
        }
        byte[] Serialize(object obj)
        {
            MemoryStream Stream = new MemoryStream();
            BinaryFormatter Formatter = new BinaryFormatter();

            Formatter.Serialize(Stream, obj);
            return Stream.ToArray();
        }

        object Deserialize(byte[] data)
        {
            MemoryStream Stream = new MemoryStream(data);
            BinaryFormatter Formatter = new BinaryFormatter();

            return Formatter.Deserialize(Stream);

        }

        private void textBox_in_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button_send_Click(object sender, EventArgs e)
        {
            foreach(Socket item in ClientList)
            {
                Send( item);
            }
            Addmessage(textBox_in.Text);
            
                
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
