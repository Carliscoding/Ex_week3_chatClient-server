﻿namespace Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView1 = new System.Windows.Forms.ListView();
            this.Button_send = new System.Windows.Forms.Button();
            this.textBox_in = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(16, 26);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(768, 301);
            this.listView1.TabIndex = 6;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.List;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // Button_send
            // 
            this.Button_send.Location = new System.Drawing.Point(696, 382);
            this.Button_send.Name = "Button_send";
            this.Button_send.Size = new System.Drawing.Size(88, 42);
            this.Button_send.TabIndex = 5;
            this.Button_send.Text = "Send";
            this.Button_send.UseVisualStyleBackColor = true;
            this.Button_send.Click += new System.EventHandler(this.Button_send_Click);
            // 
            // textBox_in
            // 
            this.textBox_in.Location = new System.Drawing.Point(16, 382);
            this.textBox_in.Multiline = true;
            this.textBox_in.Name = "textBox_in";
            this.textBox_in.Size = new System.Drawing.Size(661, 42);
            this.textBox_in.TabIndex = 4;
            this.textBox_in.TextChanged += new System.EventHandler(this.textBox_in_TextChanged);
            // 
            // Form1
            // 
            this.AcceptButton = this.Button_send;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.Button_send);
            this.Controls.Add(this.textBox_in);
            this.Name = "Form1";
            this.Text = "Server";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button Button_send;
        private System.Windows.Forms.TextBox textBox_in;
    }
}

